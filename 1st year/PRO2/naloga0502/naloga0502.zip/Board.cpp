#include "Board.h"
#include <sstream>

Board::Board(string name) : name(name) {}


string Board::toString() const {
    std::stringstream ss;
    ss << "Name: " << name << endl;
    for(Category c : categories){
        ss << " - " << c.toString() << endl;
    }
    return ss.str();
}

void Board::addCategory(const Category &category) { categories.push_back(category); }

bool Board::addTask(const string &categoryName, Task *task) {
    for(Category &c : categories){
        if(c.getName() == categoryName) {
            c.addTask(task);
            return true;
        }
    }
    return false;
}

void Board::agenda(const Date &date) const {
    for (Category c : categories){
        for (Task* t : c.getTasks()){
            if (t->getAdded().toString() == date.toString())
                cout << t->toString() << endl;
        }
    }
}

bool Board::changeName(const string &categoryName, const string &newName) {
    for(Category &c : categories){
        if(c.getName() == categoryName) {
            c.setName(newName);
            return true;
        }
    }
    return false;
}
