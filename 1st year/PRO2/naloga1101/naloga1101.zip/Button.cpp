//
// Created by timve on 2. 06. 2021.
//

#include "Button.h"

Button::Button(Position position, Size size, const std::string text) : TextView(position, size, text) {
    enabled = true;
}

bool Button::isEnabled() const {
    return enabled;
}

void Button::setEnabled(bool enabled) {
    Button::enabled = enabled;
}

void Button::onClick() {
    if(enabled) std::cout << getText();
}

void Button::draw() {
    TextView::draw();
}
