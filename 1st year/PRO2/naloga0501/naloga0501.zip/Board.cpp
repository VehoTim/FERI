#include "Board.h"
#include <sstream>

Board::Board(string name) : name(name) {}

void Board::addTask(Task *task) { tasks.push_back(task); }

string Board::toString() const {
    std::stringstream ss;
    ss << "Name: " << name << endl;
    for(Task* t : tasks){ ss << " - " << t->toString() << endl; }
    return ss.str();
}

void Board::clearTasks() {
    for(Task* t : tasks){
        delete t;
        t = nullptr;
    }
}
